// Uncomment the next line to use precompiled headers
// #include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
#include <vector>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <cassert>
#include <stdexcept>

// the global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        //  initialize random seed
        srand(static_cast<unsigned int>(time(nullptr)));  // Fixed warning
    }

    void TearDown() override {}
};

class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Use ASSERT when failure should terminate processing.
// Use EXPECT when failure should notify but allow continuing.

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

//  Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

//  Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

//  Test that max size is greater than or equal to size
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    std::vector<int>::size_type sizes[] = { 0, 1, 5, 10 };
    for (int count : sizes) {
        collection->clear();
        if (count > 0) add_entries(count);
        ASSERT_GE(collection->max_size(), collection->size());
    }
}

//  Test that capacity is greater than or equal to size
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    std::vector<int>::size_type sizes[] = { 0, 1, 5, 10 };
    for (int count : sizes) {
        collection->clear();
        if (count > 0) add_entries(count);
        ASSERT_GE(collection->capacity(), collection->size());
    }
}

//  Test that resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

//  Test that resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    add_entries(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

//  Test that resizing to zero clears the collection
TEST_F(CollectionTest, ResizingToZeroClearsCollection)
{
    add_entries(5);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

//  Test that clear() erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);
    collection->clear();
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

//  Test that erase(begin, end) erases the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

//  Test that reserve increases capacity but not size
TEST_F(CollectionTest, ReserveIncreasesCapacityOnly)
{
    auto initial_capacity = collection->capacity();
    collection->reserve(initial_capacity + 10);
    ASSERT_GE(collection->capacity(), initial_capacity + 10);
    ASSERT_EQ(collection->size(), 0); // reserve should not change size
}

//  Negative test - throws exception for out of range
TEST_F(CollectionTest, OutOfRangeAccessThrows)
{
    ASSERT_THROW(collection->at(1), std::out_of_range);
}

//  Custom positive test
TEST_F(CollectionTest, InsertedValueIsCorrect)
{
    collection->push_back(99);
    ASSERT_EQ(collection->at(0), 99);
}

//  Custom negative test
TEST_F(CollectionTest, NegativeIndexAccessThrows)
{
    ASSERT_THROW(collection->at(-1), std::out_of_range);
}

// Main function provided
int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
