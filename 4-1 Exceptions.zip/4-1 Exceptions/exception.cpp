// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
	const char* what() const noexcept override {
		return "Custom Exception occurred!";
	}
};

// Function that throws a standard runtime exception
bool do_even_more_custom_application_logic()
{
	std::cout << "Running Even More Custom Application Logic." << std::endl;
	throw std::runtime_error("An error occurred in Even More Custom Application Logic.");
	return true;
}

// Wraps the above function and catches std::exception
// Also throws the CustomException, to be caught in main()
void do_custom_application_logic()
{
	std::cout << "Running Custom Application Logic." << std::endl;

	try {
		if (do_even_more_custom_application_logic())
		{
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& e) {
		std::cout << "Caught a standard exception: " << e.what() << std::endl;
	}

	// Throwing custom exception to be caught explicitly in main()
	throw CustomException();

	std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Function that throws std::invalid_argument on division by zero
float divide(float num, float den)
{
	if (den == 0.0f)
	{
		throw std::invalid_argument("Division by zero error");
	}
	return num / den;
}

// Handles only the exception from divide()
// Uses noexcept as required
void do_division() noexcept
{
	float numerator = 10.0f;
	float denominator = 0;

	try {
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::invalid_argument& e) {
		std::cerr << "Caught an invalid argument exception: " << e.what() << std::endl;
	}
}

int main()
{
	// Full exception wrapper around main function
	// Handles custom, standard, and unknown exceptions in correct order
	try {
		std::cout << "Exceptions Tests!" << std::endl;

		do_division();

		// Handle the custom exception explicitly here
		try {
			do_custom_application_logic();
		}
		catch (const CustomException& e) {
			std::cerr << "Caught a custom exception in main: " << e.what() << std::endl;
		}
	}
	catch (const std::exception& e) {
		std::cerr << "Caught a standard exception in main: " << e.what() << std::endl;
	}
	catch (...) {
		std::cerr << "Caught an unknown exception in main!" << std::endl;
	}

	return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu